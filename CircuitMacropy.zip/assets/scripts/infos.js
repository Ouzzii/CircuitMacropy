$('body').on('click', '.infos img:last-child', function(){
    $('#settings').toggleClass('hidden')
})
